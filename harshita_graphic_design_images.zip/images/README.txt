Harshita Portfolio - Graphic Design Images

Upload these six PNG files into your GitHub repository's images/ folder.
Use these filenames in your HTML:
- coffee-poster.png
- brand-identity.png
- fashion-poster.png
- ui-design.png
- instagram-carousel.png
- tech-advertisement.png

Example:
<img src="images/coffee-poster.png" alt="Coffee Shop Promotional Poster">

These are concept/sample portfolio designs. Label them as concept work or practice projects unless they were created for real clients.
